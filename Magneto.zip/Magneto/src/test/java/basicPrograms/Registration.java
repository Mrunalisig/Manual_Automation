package basicPrograms;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Registration {

	public static void main(String []args) throws Exception
	{
		WebDriverManager.chromedriver().setup();
		  WebDriver driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().deleteAllCookies();
		  Properties p= new Properties();  
		  FileInputStream file = new FileInputStream("C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Eclipse_BackUp\\Magneto\\src\\test\\java\\propertyfile\\Login.Properties");
		  p.load(file);
		  
		  driver.navigate().to(p.getProperty("url"));
		  driver.findElement(By.linkText(p.getProperty("Create_Ac"))).click();
		  driver.findElement(By.id(p.getProperty("fname"))).sendKeys("Mrunali");
	      driver.findElement(By.id(p.getProperty("lname"))).sendKeys("Shigawan");
	      driver.findElement(By.name(p.getProperty("email"))).sendKeys("mrunalisig.ms@gmail.com");
	      driver.findElement(By.id(p.getProperty("pass"))).sendKeys("Mrunu@1319");
	      driver.findElement(By.id(p.getProperty("cpass"))).sendKeys("Mrunu@1319");
	      driver.findElement(By.xpath(p.getProperty("SignUp"))).click();  
	      driver.close();
	      
	}
	
}
