package basicPrograms;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginandLogout {
	public static void main(String []args) throws Exception
	{
	
	  WebDriverManager.chromedriver().setup();
	  WebDriver driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().deleteAllCookies();
	  Properties p= new Properties();  
	  FileInputStream file = new FileInputStream("C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Eclipse_BackUp\\Magneto\\src\\test\\java\\propertyfile\\Login.Properties");
	  p.load(file);
	  
	  //Entering Url
	  driver.navigate().to(p.getProperty("url"));
	  driver.findElement(By.xpath(p.getProperty("Sign_In"))).click();

	  //Entering Sign IN Details
	  driver.findElement(By.id(p.getProperty("mail"))).sendKeys("mrunalisig.ms@gmail.com");
	  driver.findElement(By.id(p.getProperty("password"))).sendKeys("Mrunu@1319");
	  Thread.sleep(2000);
	  driver.findElement(By.id(p.getProperty("C_Sign_In"))).click();
	 
	  //Sign_out the current account
	  driver.findElement(By.xpath(p.getProperty("Acc_Setting"))).click();
	  Thread.sleep(2000);
	  driver.findElement(By.linkText("Sign Out")).click();
	  Thread.sleep(2000);

	  driver.close();

     }
}
