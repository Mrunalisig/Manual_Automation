package Hybrid;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ReadExcel {
	public void readExcel(WebDriver Driver) throws Exception
	{
		FileInputStream file = new FileInputStream("C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Browser Extension\\Megneto.xlsx");
		@SuppressWarnings("resource")
		XSSFWorkbook w = new XSSFWorkbook(file);
		XSSFSheet s= w.getSheet("Hybrid");
		
		int size=s.getLastRowNum();
		System.out.println("No.of Keywords:"+size);
		
		Operational_Class o= new Operational_Class();
		
		for(int i=1;i<=3;i++)
		{
			String username= s.getRow(i).getCell(1).getStringCellValue();
			String password= s.getRow(i).getCell(2).getStringCellValue();
			System.out.println(username+"\t\t"+password);
			
			try {
				for(int j=1;j<=size;j++)
				{
					String key = s.getRow(j).getCell(0).getStringCellValue();
				    if (key.equals("Maximize Browser"))
				    {
				    	o.maximizeBroswer(Driver);
				    	System.out.println(key);
				    	Thread.sleep(2000);
				    }
				    else if (key.equals("Enter URL"))
				    {
				    	o.url(Driver);
				    	System.out.println(key);
				    	Thread.sleep(2000);
				    }
				    else if (key.equals("Enter Username"))
				    {
				    	o.username(Driver, username);
				    	System.out.println(key);
				    	Thread.sleep(2000);
				    }
				    else if (key.equals("Enter Password"))
				    {
				    	o.password(Driver, password);
				    	System.out.println(key);
				    	Thread.sleep(2000);
				    }
				    else if (key.equals("Click on Login Button"))
				    {
				    	o.loginbutton(Driver);
				    	System.out.println(key);
				    	Thread.sleep(2000);
				    }
				    else if (key.equals("smokeTesting"))
				    {
				    	o.smokeTesting(Driver);
				    	System.out.println(key);
				    	Thread.sleep(2000);
				    }
				    
				    else if (key.equals("Click on Logout Button"))
				    {
				    	o.logoutbutton(Driver);
				    	System.out.println(key);
				    	Thread.sleep(2000);
				    	System.out.println("Valid Credential");
				    	System.out.println("");
				    	s.getRow(i).createCell(3).setCellValue("Valid Credential");
				    }
				}
				
			}
			catch(Exception e)
			{
				System.out.println("Invalid Credential");
		    	System.out.println("");
		    	s.getRow(i).createCell(3).setCellValue("Invalid Credential");
			}
		}
		o.closeBroswer(Driver);
		FileOutputStream out = new FileOutputStream("C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Browser Extension\\Megneto.xlsx");
		w.write(out);
	}
}
