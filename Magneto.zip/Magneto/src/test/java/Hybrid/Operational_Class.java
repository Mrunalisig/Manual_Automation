package Hybrid;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.google.common.io.Files;

public class Operational_Class {
	public void maximizeBroswer(WebDriver driver)
	{
		driver.manage().window().maximize();
	}
	
	public void url(WebDriver driver)
	{
		driver.get("https://magento.softwaretestingboard.com/");
		driver.findElement(By.xpath("/html/body/div[1]/header/div[1]/div/ul/li[2]/a")).click();
	}
	
	public void username(WebDriver driver,String usn)
	{
		driver.findElement(By.id("email")).sendKeys(usn);
	}
	
	public void password(WebDriver driver,String pwd)
	{
		driver.findElement(By.id("pass")).sendKeys(pwd);
	}
	
	public void loginbutton(WebDriver driver)
	{
		driver.findElement(By.id("send2")).click();
	}
	
	public void smokeTesting(WebDriver driver) throws Exception
	{
		Actions a=new Actions(driver);
		List<WebElement>ls=driver.findElements(By.xpath("//*[@id=\"ui-id-2\"]/li"));
		int size =ls.size();
		
		System.out.println(size);
		
		for(int i=1;i<=size;i++)
		{
			System.out.println(driver.findElement(By.xpath("//*[@id=\"ui-id-2\"]/li["+i+"]")).getText());
			a.moveToElement(driver.findElement(By.xpath("//*[@id=\"ui-id-2\"]/li["+i+"]"))).click().perform();
			File f= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		    Files.copy(f, new FileOutputStream("C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Eclipse_BackUp\\Magneto\\src\\test\\resources\\Screenshots\\smoketestingwebelement["+i+"].png"));
			Thread.sleep(2000);
		}
	}	
	
//	public void welcomeAdmin(WebDriver driver)
//	{
//		driver.findElement(By.xpath("//span[@class='oxd-userdropdown-tab']")).click();
//	}
	
	public void logoutbutton(WebDriver driver) throws InterruptedException
	{
		 driver.findElement(By.xpath("/html/body/div[1]/header/div[1]/div/ul/li[2]/span/button")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.linkText("Sign Out")).click();
	}
	public void closeBroswer(WebDriver driver)
	{
		driver.close();
	}
}
