package crossBrowserTesting;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class CrossbrowserTesting {

	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		System.out.println("Enter 1 to execute script on google chrome. \n Enter 2 to execute script on Mozilla Firefox");
		int choice =s.nextInt();
		WebDriver driver =null;
		switch(choice)
		{
		case 1:
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Browser Extension\\chromedriver.exe");
			driver = new ChromeDriver();
			break;
		
		case 2:
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Browser Extension\\geckodriver.exe");
			driver = new FirefoxDriver();
			break;
			
	}

}
}
