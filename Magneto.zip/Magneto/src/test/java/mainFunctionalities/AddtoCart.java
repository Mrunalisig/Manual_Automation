package mainFunctionalities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AddtoCart {

	public static void main(String[] args) throws Exception {
		WebDriverManager.chromedriver().setup();
		  WebDriver driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().deleteAllCookies();
		  Properties p= new Properties();  
		  FileInputStream file = new FileInputStream("C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Eclipse_BackUp\\Magneto\\src\\test\\java\\propertyfile\\Login.Properties");
		  p.load(file);
		  
		  //Entering Url
		  driver.navigate().to(p.getProperty("url"));
		  driver.findElement(By.xpath(p.getProperty("Sign_In"))).click();

		  //Entering Sign IN Details
		  driver.findElement(By.id(p.getProperty("mail"))).sendKeys("mrunalisig.ms@gmail.com");
		  driver.findElement(By.id(p.getProperty("password"))).sendKeys("Mrunu@1319");
		  Thread.sleep(1000);
		  driver.findElement(By.id(p.getProperty("C_Sign_In"))).click();
		  Thread.sleep(1000);
		  
		  //Selecting Categories and filters
		  driver.findElement(By.xpath("//*[@id=\"ui-id-3\"]/span")).click();
		  driver.findElement(By.linkText("Hoodies & Sweatshirts")).click();
		  //Fliters
		  driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[1]/div[1]")).click();
		  driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[1]/div[2]/ol/li[2]/a")).click();
		  //size
		  driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[1]/div[1]")).click();
		  driver.findElement(By.xpath("//*[@id=\"narrow-by-list\"]/div[1]/div[2]/div/div/a[1]/div")).click();
		  Thread.sleep(1000);
		  
		  JavascriptExecutor js=(JavascriptExecutor)driver;
		  //Scroll Web element
		  WebElement w=driver.findElement(By.xpath("//*[@id=\"option-label-size-143-item-166\"]"));
		  js.executeScript("window.scrollBy(0,300)");
		  
		  //Select the item  //*[@id="maincontent"]/div[3]/div[1]/div[3]/ol/li[1]
		  Actions a=new Actions(driver);
		  a.moveToElement(driver.findElement(By.xpath("//*[@id=\"maincontent\"]/div[3]/div[1]/div[3]/ol/li[1]"))).click().perform();
			
			js.executeScript("window.scrollBy(0,300)");
			driver.findElement(By.xpath("//*[@id=\"option-label-size-143-item-167\"]")).click();
			driver.findElement(By.xpath("//*[@id=\"option-label-color-93-item-53\"]")).click();
			driver.findElement(By.id("qty")).clear();
			driver.findElement(By.id("qty")).sendKeys("2");
			driver.findElement(By.id("product-addtocart-button")).click();
			
			//Scroll to Top
			js.executeScript("window.scrollTo(document.body.scrollHeight,0)");

			//View Cart item
			driver.findElement(By.xpath("/html/body/div[1]/header/div[2]/div[1]/a")).click();
			File f= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		    Files.copy(f, new FileOutputStream("C:\\Users\\Dell\\OneDrive\\Desktop\\AutomationTesting\\Eclipse_BackUp\\Magneto\\src\\test\\resources\\Screenshots\\AddtoCartItems\\ViewCart.png"));
			
		  
	}
}
